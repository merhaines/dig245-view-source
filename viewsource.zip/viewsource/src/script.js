document.querySelector("p1").addEventListener("mouseover", function(){
  alert("Do-re-mi-fa-so-la-ti-do")
})

